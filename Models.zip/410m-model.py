"""
@authors: Simone Baratella, Kassandra Briola, Samuele Antonelli
"""

# import libraries
from transformers import GPTNeoXForCausalLM, AutoTokenizer   


"""
Load the GPT-NEOX pre-trained model from a given checkpoint with the scepific identifier 
store it the downloaded files in a defined directory.
"""
model = GPTNeoXForCausalLM.from_pretrained(                             
  "EleutherAI/pythia-410m",                                              
  cache_dir="./pythia-410m",                                             
)


"""
Load the corresponding tokenizer to be used based on the GPT-NEOX model identifier 
store it in a defined directory
"""
tokenizer = AutoTokenizer.from_pretrained(                              
  "EleutherAI/pythia-410m",                                               
  cache_dir="./pythia-410m",                                             
)
 
 
"""
Function that takes a user's question as input and generates a response
"""
def ask_question(question,                #the user's input question                    
                 max_length=100,          #set the maximum length of the generated response
                 temperature=0.4,         #set the randomness of the generated response (lower values = more grounded answer)
                 top_p=0.2,               #set the diversity of the generated response (chooses from top 20% probable next tokens)                    
                 top_k=30,                #set the number of tokens to consider at each generation step                    
                 repetition_penalty=1.5): # penalizes repetitive responses                             
    
    inputs = tokenizer(question, return_tensors="pt")


    # generate tokens using the model based on the input configuration
    tokens = model.generate(**inputs,
                            max_length=max_length,
                            do_sample=True,          # Enable sampling to make generation more diverse
                            top_p=top_p,
                            temperature=temperature,
                            top_k=top_k,
                            repetition_penalty=repetition_penalty,
                            no_repeat_ngram_size=2,  # Prevent repeating the same 2-gram
                            num_beams=2,             # Use beam search with 2 beams 
                            eos_token_id=tokenizer.eos_token_id)  # Set the end of sentence token

    # DECODE THE GENERATED TOKENS TO A HUMAN-READABLE TEXT
    answers = [tokenizer.decode(tokens[0], skip_special_tokens=True)]   
    return answers


"""
CHAT INTERFACE LOOP TO KEEP ASKING FOR USER QUESTIONS
"""
print("GPT-NeoX Chat Interface. Type 'exit' to stop.")                  
while True:
    
    user_input = input("QUESTION HERE: ")                            
    
    if user_input.lower() == 'exit':     # Lowercase check to exit the loop
        print("Exiting chat. Goodbye!")
        break
   
    responses = ask_question(user_input) # Obtain responses from the ask_question function
    
    for idx, response in enumerate(responses, start=1): # Display each response
        print(f"Answer {idx}: {response}")